import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyAddComponent } from './company-add/company-add.component';
import { CompanyDetailsComponent } from './company-details/company-details.component';
import { StockListComponent } from './stock-list/stock-list.component';

const routes: Routes = [
  { path: '', component: CompanyDetailsComponent },
  { path: 'add', component: CompanyAddComponent },
  { path: 'edit/:code', component: CompanyAddComponent },
  { path: 'list', component: StockListComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {
}
