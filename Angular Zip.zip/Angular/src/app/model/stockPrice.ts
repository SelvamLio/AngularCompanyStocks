import { Time } from '@angular/common';

export class StockPrice{
    CompanyId?: string;    
    stockPrice?: number;
    createdDate?: Date;
}