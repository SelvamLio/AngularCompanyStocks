export class StockExchange {
    stockId?: number;
    stockName?: string;
}